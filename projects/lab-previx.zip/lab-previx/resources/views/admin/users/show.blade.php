<!DOCTYPE html>
<html>
    <head>
        <title>User Details</title>
    </head>
    <body>
        <h1>Details for: {{ $user }}</h1>
    </body>
</html>