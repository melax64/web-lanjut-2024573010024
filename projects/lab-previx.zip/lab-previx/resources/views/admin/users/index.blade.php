<!DOCTYPE html>
<html>
    <head>
        <title>Users</title>
    </head>
    <body>
        <h1>User List</h1>
        <ul>
            @foreach ($Users as $User)
                <li>{{ $user }}</li>
            @endforeach
        </ul>
    </body>
</html>